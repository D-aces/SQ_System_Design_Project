[Video File](https://www.google.com](https://drive.google.com/file/d/1ZXA-iNqBQbKHRY1ERZDQH0zJgmt5GuqY/view?usp=drive_link)https://drive.google.com/file/d/1ZXA-iNqBQbKHRY1ERZDQH0zJgmt5GuqY/view?usp=drive_link)

Name: Dmitri Rios Nadeau
Student ID: 100783206
